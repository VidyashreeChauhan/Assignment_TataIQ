import './App.css';
import "bootstrap/dist/css/bootstrap.min.css";
import HomePage from './Components/HomePage';
import Articles from './Components/Articles';
import Footer from './Components/Footer';


function App() {
  return (
    <div className="App">
     <HomePage/>
     <Articles/>
     <Footer/>
    </div>
  );
}

export default App;
