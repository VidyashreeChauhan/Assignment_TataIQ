import React from 'react'
import { Container, Navbar } from "react-bootstrap";
import Articles from '../Components/Articles';
import './../Custom/Custom.scss'

function NavBar() {
  return (
    <Navbar>
      <Container>
        <Navbar.Brand href=<Articles/> className="Brand">
        <img src={require("./../Assests/logo.png")} width="25%" alt="" />
          WILDLIFE
        </Navbar.Brand>
        <Navbar.Toggle />
        <Navbar.Collapse className="justify-content-end">
          <div className="Nav_Text">
            <Navbar.Text className="Text">Blog</Navbar.Text>
            <Navbar.Text className="Text">Contact</Navbar.Text>
            <Navbar.Text className="Text">
              <i class="fa-solid fa-magnifying-glass"></i>
            </Navbar.Text>
            <Navbar.Text className="Text">Sign In </Navbar.Text>
          </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavBar