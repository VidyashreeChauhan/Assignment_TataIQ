// const e = require("express");
let mongoose = require("mongoose");
let dbUrl =
  "mongodb+srv://Vidyashree_G:vidya123@cluster0.kifsycp.mongodb.net/?retryWrites=true&w=majority";
module.exports.mongoConnect = mongoose.connect(
  dbUrl,
  { useNewUrlParser: true, useUnifiedTopology: true },
  (err) => {
    if (!err) {
      console.log("Db Connected Sucessfullt....!");
    } else {
      console.log("Db connection failed......!");
    }
  }
);
