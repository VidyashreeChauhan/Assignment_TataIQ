let express = require("express");
let app = express();
let port = 5700;

require('./config/db')
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use((err, req, res) => {
  res.status(500).json({
    error: true,
    message: err.message,
    data: null,
  });
});
app.listen(port, () => {
  console.log(`app is listning to port number ${port}`);
});
