const mongoose = require("mongoose");

let Schema = mongoose.Schema;

let CardSchema = new Schema({
  cardTitle: {
    type: String,
    required: true,
  },
  cardDetails: {
    type: String,
    required: true,
  },
  cardImage: String,
});

module.exports ={CardSchema};