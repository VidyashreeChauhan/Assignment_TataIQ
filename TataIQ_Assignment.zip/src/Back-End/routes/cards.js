let express =require('express');
let router = express.Router();

/* GET cards listing. */
router.get('/', function (req, res, next) {
    res.json({
        "cards": [{
            id: 1,
            url: "url('https://images.unsplash.com/photo-1543946207-39bd91e70ca7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8ZGVlciUyMGluJTIwZm9yZXN0fGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60')",
            title: "Deer",
            subTitle: "Natural Investigation"
        }, {
            id: 2,
            url: "",
            title: "Hiccup",
            subTitle: "hiccup"
        },
        {
            id: 3,
            url: "",
            title: "Hiccup",
            subTitle: "hiccup"
        }]
    });
});