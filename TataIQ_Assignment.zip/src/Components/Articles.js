import React, { Component } from "react";
import { Card } from "react-bootstrap";
import "./../Custom/Custom.scss";

function Articles (){
  let articles = [];
    fetch('/cards')
      .then(articles => {
        console.log(articles);
        return articles.json()
      })
      .then(articles => {
        console.log(articles);
        articles = articles;
      });
  return (
    <div id="article" className="Articles">
      <h1>Latest Articles</h1>
      <h5>
        <Card.Subtitle className="mb-8 text-muted" style={{ fontSize: "1.5rem" }}>
          Breaking news from the wild
        </Card.Subtitle>
      </h5>
      <div
        style={{
          display: "flex",
          justifyContent: "space-around",
          marginTop: "5rem",
        }}
      >
        <div>
          <Card
            className="Card"
            style={{
              backgroundImage:
                "url('https://images.unsplash.com/photo-1543946207-39bd91e70ca7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8ZGVlciUyMGluJTIwZm9yZXN0fGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60')",
            }}
          >
            <Card.Body>
            <div style={{marginTop:"100%"}}>
              <Card.Title style={{color:"#ffffff"}}>Deer</Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                Natural Investigation
              </Card.Subtitle>
              </div>
            </Card.Body>
          </Card>
        </div>
        <div>
          <Card
            className="Card"
            style={{
              backgroundImage:
                "url('https://cloudfront.slrlounge.com/wp-content/uploads/2016/02/Untitled-1.jpg')",
            }}
          >
            <Card.Body>
            <div style={{marginTop:"100%"}}>
              <Card.Title style={{color:"#ffffff"}}>Squirrel</Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                Kamikaze Squirrels
              </Card.Subtitle>
              </div>
            </Card.Body>
          </Card>
        </div>
        <div>
          <Card
            className="Card"
            style={{
              backgroundImage:
                "url('https://www.nps.gov/common/uploads/grid_builder/mountains/crop1_1/77205E9B-F9E2-ABDD-6C3DFC60F4D7006E.jpg?width=640&quality=90&mode=crop')",
            }}
          >
            <Card.Body>
            <div style={{marginTop:"100%"}}>
              <Card.Title style={{color:"#ffffff"}}>Bird</Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                Birds Flight Club
              </Card.Subtitle>
              </div>
            </Card.Body> 
          </Card>
        </div>
      </div>
      <div>
      </div>
      <div>
        <br />
      </div>
    </div>
  );
}

export default Articles;
