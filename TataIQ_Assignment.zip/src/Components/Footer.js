import React from "react";
import { Col, Row } from "react-bootstrap";
import Form_Feild from "./Form_Feild";

const Footer = () => {
  return (
    <div>
      <Row>
        <Col lg={2} className="Home_Col2">
          <div className="Home_Col2_Content">
            <img src={require("./../Assests/logo.png")} width="35%" alt="" />
            <div>
              <h4>WILDLIFE</h4>
              <a href="#article"> Articles</a>
              <a>About Us</a>
              <a>Learn More</a>
            </div>
            <div className="Home_Col2_Icon">
              <i class="fa-brands fa-facebook"></i>
              <i class="fa-brands fa-square-instagram"></i>
              <i class="fa-brands fa-telegram"></i>
              <i class="fa-brands fa-square-whatsapp"></i>
            </div>
          </div>
        <Form_Feild/>
        </Col>
      </Row>
    </div>
  );
};

export default Footer;
