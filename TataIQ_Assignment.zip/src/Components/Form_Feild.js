import React from "react";
import { Form } from "react-bootstrap";

const Form_Feild = () => {
  return (
    <div>
      <Form
        style={{
          width: "30rem"
        }}
      >
        <Form.Group className="mb-2" controlId="exampleForm.ControlInput1">
          <Form.Label style={{color:"white"}}>Name</Form.Label>
          <Form.Control type="email" placeholder="Enter your Name" />
        </Form.Group>
        <Form.Group className="mb-2" controlId="exampleForm.ControlInput1">
          <Form.Label style={{color:"white"}}>Title</Form.Label>
          <Form.Control type="email" placeholder="Enter Title" />
        </Form.Group>
        <Form.Group className="mb-2" controlId="exampleForm.ControlTextarea1">
          <Form.Label style={{color:"white"}}>Message</Form.Label>
          <Form.Control as="textarea" rows={3} />
        </Form.Group>
      </Form>
    </div>
  );
};

export default Form_Feild;
