import React from 'react'
import { Button, Col, Row } from 'react-bootstrap'
import NavBar from '../Atoms/NavBar'
import "./../App.css"
import "./../Custom/Custom.scss"
import Articles from './Articles'

function HomePage() {
  return (
    <div className="Main_Div">
      <NavBar />
      <Row>
        <Col lg={4} sm={5} className="Home_Col">
          <div className="Home_Col_div">
            <h1>Survival</h1>
            <p>
              What this means is that we exist to help protect our environment
              and do in number of ways. You can save the planet by donation.
            </p><br></br>
            <Button className="donate">Donate</Button>
          </div>
        </Col>
      </Row>
    </div>
  );
}

export default HomePage